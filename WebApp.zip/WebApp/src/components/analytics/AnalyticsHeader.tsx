/**
 * DEPRECATED: This component/file is no longer used.
 * We now use simple analytics without complex components.
 * See /pages/admin/Analytics.tsx for the new simple analytics dashboard.
 */
export default null;
